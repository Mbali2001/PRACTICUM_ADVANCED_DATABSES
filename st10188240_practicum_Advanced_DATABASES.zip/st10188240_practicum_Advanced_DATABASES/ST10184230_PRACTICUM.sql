
--QUESTION 1
CREATE TABLE INSTRUCTOR(
INS_ID NUMBER PRIMARY KEY,
 INS_FNAME VARCHAR2(50) NOT NULL,
INS_SNAME VARCHAR2(50) NOT NULL,
 INS_CONTACT VARCHAR2(50) NOT NULL,
 INS_LEVEL NUMBER NOT NULL
);

DROP TABLE CUSTOMER
CREATE TABLE CUSTOMER (
 CUST_ID VARCHAR(5) PRIMARY KEY,
 CUST_FNAME VARCHAR2(50) NOT NULL,
 CUST_SNAME VARCHAR2(50) NOT NULL,
 CUST_ADDRESS VARCHAR2(150) NOT NULL,
 CUST_CONTACT VARCHAR2(20)
);

CREATE TABLE DIVE (
DIVE_ID NUMBER PRIMARY KEY,
 DIVE_NAME VARCHAR2(50) NOT NULL,
 DIVE_DURATION VARCHAR2(50) NOT NULL,
 DIVE_LOCATION VARCHAR2(50) NOT NULL,
DIVE_EXP_LEVEL NUMBER NOT NULL,
DIVE_COST NUMBER NOT NULL
);

DROP TABLE DIVE_EVENT
CREATE TABLE DIVE_EVENT (
 DIVE_EVENT_ID VARCHAR2(6) PRIMARY KEY,
DIVE_DATE  DATE NOT NULL,
DIVE_PARTICIPANTS NUMBER NOT NULL,
 INS_ID NUMBER NOT NULL,
 CUST_ID VARCHAR(5) NOT NULL,
 DIVE_ID NUMBER  NOT NULL,
 FOREIGN KEY (INS_ID) REFERENCES INSTRUCTOR(INS_ID),
 FOREIGN KEY (CUST_ID) REFERENCES CUSTOMER(CUST_ID),
 FOREIGN KEY (DIVE_ID) REFERENCES DIVE(DIVE_ID)
);

-- INSERT into intructor
INSERT INTO INSTRUCTOR VALUES (101, 'James', 'Willis', '0843569851',7);
INSERT INTO INSTRUCTOR VALUES (102, 'Sam', 'Wait', '0763698521',2);
INSERT INTO INSTRUCTOR VALUES (103, 'Sally', 'Gumede', '0786598521',8);
INSERT INTO INSTRUCTOR VALUES (104, 'Bob', 'Du Preez', '0796369857',3);
INSERT INTO INSTRUCTOR VALUES (105, 'Simon', 'Jones', '0826598741',9);

-- instert into customer
INSERT INTO CUSTOMER VALUES ('C115','Heinrich', 'Willis', '3 Main Road','0821253659');
INSERT INTO CUSTOMER VALUES ('C116','David','	Watson','13 Cape Road','0769658547');
INSERT INTO CUSTOMER VALUES ('C117','	Waldo','	Smith','	3 Mountain Road','0863256574');
INSERT INTO CUSTOMER VALUES ('C118','	Alex','	Hanson','	8 Circle Road','0762356587');
INSERT INTO CUSTOMER VALUES ('C119','	Kuhle','Bitterhout','15 Main Road','0821235258');
INSERT INTO CUSTOMER VALUES ('C120','Thando','Zolani','	88 Summer Road','0847541254');
INSERT INTO CUSTOMER VALUES ('C121','	Philip','	Jackson','	3 Long Road','0745556658');
INSERT INTO CUSTOMER VALUES ('C122','	Sarah','	Jones','	7 Sea Road','0814745745');
INSERT INTO CUSTOMER VALUES ('C123','	Catherine','Howard','31 Lake Side Road','0822232521');
SELECT * FROM CUSTOMER;


--INTSERT INTO DIVE 
INSERT INTO DIVE VALUES (550,'Shark Dive ','	3 hours ','	Shark Point', 	8,	500
);
INSERT INTO DIVE VALUES (551,'	Coral Dive',' 	1 hour',' 	Break Point ',	7,	300
);
INSERT INTO DIVE VALUES (552,'	Wave Crescent','  	2 hours ','	Ship wreck ally ',	3,	800
					
);
INSERT INTO DIVE VALUES (553,'	Underwater 	Exploration','  	1 hour',' 	Coral ally', 	2,	250
					
);
INSERT INTO DIVE VALUES (554,'	Underwater Adventure',' 	 	3 hours',' 	Sandy Beach ',	3,	750
				
);
INSERT INTO DIVE VALUES (555,'	Deep Blue	Ocean','  	30 minutes 	','Lazy Waves ',	2	,120
);
INSERT INTO DIVE VALUES (556,'	Rough Seas ','	1 hour 	Pipe ,',	9	,700
);
INSERT INTO DIVE VALUES (557,'	White Water',' 	2 hours ','	Drifts', 	5,	200
);
INSERT INTO DIVE VALUES (558,'	Current Adventure',' 		2 hours',' 	Rock Lands', 	3,	150
				
);

--INSERT DIVE_EVENT

INSERT INTO DIVE_EVENT VALUES ('de_101','	15-Jul-17',	5	,103,	'C115',	558
 );
INSERT INTO DIVE_EVENT VALUES ('de_102','	16-Jul-17',	7,	102,'C117',	555
);
INSERT INTO DIVE_EVENT VALUES ('de_103','18-Jul-17',	8,	104,'C118',	552
);
INSERT INTO DIVE_EVENT VALUES ('de_104','	19-Jul-17',	3	,101,'C119',	551
);
INSERT INTO DIVE_EVENT VALUES ('de_105','	21-Jul-17',	5	,104,'C121',	558
);

INSERT INTO DIVE_EVENT VALUES ('de_106','22-Jul-17',8,105,'C120',	556
);
INSERT INTO DIVE_EVENT VALUES ('de_107','25-Jul-17',	10	,105,'C115',	554

);
INSERT INTO DIVE_EVENT VALUES ('de_108','	27-Jul-17',	5,	101,'C122',	552

);
INSERT INTO DIVE_EVENT VALUES ('de_109','28-Jul-17',	3,	102	,'C123',553
);
SELECT * FROM DIVE_EVENT;

--Question 2
-- 
CREATE USER admin_user IDENTIFIED BY admin_password;


CREATE USER general_user IDENTIFIED BY general_password;

GRANT DBA TO admin_user;


GRANT CONNECT, RESOURCE TO general_user;


GRANT SELECT, INSERT, UPDATE, DELETE ON Instructor TO general_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON Customer TO general_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON Dive TO general_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON Dive_Event TO general_user;


--question 3
SELECT 
CUSTOMER.CUST_FNAME || ' ' || CUSTOMER.CUST_SNAME AS customer_fullname,
 INSTRUCTOR.INS_FNAME||' ' ||  INSTRUCTOR.INS_SNAME AS instructor_fullname ,
DIVE.DIVE_LOCATION,
DIVE_EVENT.DIVE_PARTICIPANTS
FROM
DIVE_EVENT
JOIN  INSTRUCTOR ON DIVE_EVENT.CUST_ID =  INSTRUCTOR.INS_ID
JOIN CUSTOMER ON  DIVE_EVENT.CUST_ID = CUSTOMER.CUST_ID
JOIN DIVE ON DIVE_EVENT.DIVE_ID= DIVE.DIVE_ID
WHERE DIVE_EVENT.DIVE_PARTICIPANTS BETWEEN 8 AND 10;


 
--QUESTION 4
SET SERVEROUTPUT ON;
DECLARE
    CURSOR dive_event_cursor IS
        SELECT 
            DIVE .DIVE_NAME,
            DIVE_EVENT.DIVE_DATE
        FROM 
           DIVE_EVENT
        JOIN 
           DIVE  ON DIVE_EVENT.DIVE_ID = DIVE.DIVE_ID
        WHERE 
            DIVE_EVENT.DIVE_PARTICIPANTS >= 10;
    
    -- Variables to store the fetched data
    v_dive_name Dive.dive_name%TYPE;
    v_dive_date Dive_Event.dive_date%TYPE;
BEGIN
    -- Open the cursor
    OPEN dive_event_cursor;
    
    -- Loop through the cursor and fetch each row
    LOOP
        FETCH dive_event_cursor INTO v_dive_name, v_dive_date;
        EXIT WHEN dive_event_cursor%NOTFOUND;
        
        -- Display the fetched data
        DBMS_OUTPUT.PUT_LINE('Dive Name: ' || v_dive_name || ', Date: ' || TO_CHAR(v_dive_date, 'YYYY-MM-DD'));
    END LOOP;
    
    -- Close the cursor
    CLOSE dive_event_cursor;
END;
/
 


--QUESTION 5

SET SERVEROUTPUT ON;

DECLARE
 
    CURSOR report_cursor IS
    SELECT
   CUSTOMER.CUST_FNAME || ' ' || CUSTOMER.CUST_SNAME AS customer_full_name,
           DIVE_DIVE_NAME,
           DIVE_EVENTS.DIVE_PARTICIPANT,
      INSTRUCTOR.INS_FNAME||' ' ||  INSTRUCTOR.INS_SNAME   AS instructor_full_name
        FROM 
         DIVE_EVENT
        JOIN 
        CUSTOMER
      ON   DIVE_EVENT.CUST_ID = CUSTOMER.CUST_ID
        JOIN 
   DIVE     ON DIVE_EVENT.DIVE_ID = DIVE.DIVE_ID
        JOIN 
        INSTRUCTOR
            ON DIVE_EVENT.INS_ID =  INSTRUCTOR.INS_ID
    WHERE  DIVE.DIVE_COST=500;

    -- Variables to store the fetched data
    v_customer_full_name Customer.cust_fname%TYPE || ' ' || Customer.cust_sname%TYPE;
    v_dive_name Dive.dive_name%TYPE;
    v_dive_participants Dive_Event.dive_participants%TYPE;
    v_instructor_full_name Instructor.ins_fname%TYPE || ' ' || Instructor.ins_sname%TYPE;
BEGIN
    -- Open the cursor
    OPEN report_cursor;

    -- Loop through the cursor and fetch each row
    LOOP
        FETCH report_cursor INTO v_customer_full_name, v_dive_name, v_dive_participants, v_instructor_full_name;
        EXIT WHEN report_cursor%NOTFOUND;

        -- Display the fetched data
        DBMS_OUTPUT.PUT_LINE('Customer Full Name: ' || v_customer_full_name || 
                             ', Dive Event Name: ' || v_dive_name || 
                             ', Dive Participants: ' || v_dive_participants || 
                             ', Instructor Full Name: ' || v_instructor_full_name);
    END LOOP;

    -- Close the cursor
    CLOSE report_cursor;
END;
/

--question 6
CREATE VIEW Vw_Dive_Event      AS
SELECT 
 INSTRUCTOR.INS_ID,
    CUSTOMER.CUST_ID,
  CUSTOMER.CUST_ADDRESS,
  DIVE.DIVE_DURATION,

FROM 
   DIVE_EVENT
JOIN 
   INSTRUCTOR ON   DIVE_EVENT.INS_ID =  INSTRUCTOR.INS_ID
JOIN 
    CUSTOMER ON   DIVE_EVENT.CUST_ID =CUSTOMER.CUST_ID
JOIN 
  DIVE ON  DIVE_EVENT.DIVE_ID =DIVE.DIVE_ID
WHERE 
      DIVE_EVENT.DIVE_DATE < DATE '2023-07-19';
      
      SELECT * FROM Vw_Dive_Event;
      
      --QUESTION 7
    CREATE OR REPLACE TRIGGER New_Dive_Event
BEFORE INSERT OR UPDATE ON  DIVE_EVENT
FOR EACH ROW
BEGIN
    IF :NEW.dive_participants <= 0 OR :NEW.dive_participants > 20 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Number of participants must be between 1 and 20.');
    END IF;
END;
/

BEGIN
    INSERT INTO  DIVE_EVENT
    VALUES (1, 1, 1, DATE '2023-06-24', 0);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/


BEGIN
    INSERT INTO  DIVE_EVENT
    VALUES (1, 1, 1, DATE '2023-06-24', 21);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/
-- This should fail because participants are less than or equal to 0
BEGIN
    UPDATE Dive_Event
    SET dive_participants = -5
    WHERE dive_ID = 1 AND ins_ID = 1 AND cust_id = 1;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/


BEGIN
    UPDATE DIVE_EVENT
    SET DIVE_PARTICIPANTS = 25
    WHERE dive_ID = 1 AND ins_ID = 1 AND cust_id = 1;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/


-- QUESTION 8
-- Create the stored procedure
CREATE OR REPLACE PROCEDURE sp_customer_details (
 p_sales_num IN SALES.SALES_NUM%TYPE
) IS
 v_cust_id CUSTOMER.CUST_ID%TYPE;
 v_cust_fname CUSTOMER.CUST_FNAME%TYPE;
 v_cust_sname CUSTOMER.CUST_SNAME%TYPE;
 v_cust_contact CUSTOMER.CUST_CONTACT%TYPE;
BEGIN
 -- Retrieve customer details based on sales number
 SELECT CUSTOMER.CUST_ID, CUSTOMER.CUST_FNAME, CUSTOMER.CUST_SNAME,
CUSTOMER.CUST_CONTACT
 INTO v_cust_id, v_cust_fname, v_cust_sname, v_cust_contact
 FROM CUSTOMER 
 JOIN SALES ON CUSTOMER.CUST_ID = SALES.CUST_ID
 WHERE SALES.SALES_NUM = p_sales_num;
 -- Display the customer details
 DBMS_OUTPUT.PUT_LINE('Customer ID: ' || v_cust_id);
 DBMS_OUTPUT.PUT_LINE('First Name: ' || v_cust_fname);
 DBMS_OUTPUT.PUT_LINE('Surname: ' || v_cust_sname);
 DBMS_OUTPUT.PUT_LINE('Contact Number: ' || v_cust_contact);
EXCEPTION
 WHEN NO_DATA_FOUND THEN
 DBMS_OUTPUT.PUT_LINE('No customer found for the given sales number.');
 WHEN OTHERS THEN
 DBMS_OUTPUT.PUT_LINE('An error occurred: ' || SQLERRM);
END sp_customer_details;
/
--Execute the Stored Procedure
-- Enable DBMS_OUTPUT to display the output in SQL*Plus or SQL Developer
SET SERVEROUTPUT ON;
-- Declare a block to execute the stored procedure
BEGIN
 -- Call the stored procedure with a valid sales number
 sp_customer_details(101);
 -- Call the stored procedure with an invalid sales number to test exception 
handling
 sp_customer_details(999);
END
/
-- QUESTION 9
CREATE OR REPLACE FUNCTION fn_IT_Gear (
 p_cust_id IN CUSTOMER.CUST_ID%TYPE
) RETURN VARCHAR2 IS
 v_sales_num SALES.SALES_NUM%TYPE;
 v_sales_date SALES.SALES_DATE%TYPE;
 v_sales_amt SALES.SALES_AMT%TYPE;
 v_stock_model STOCK.STOCK_MODEL%TYPE;
 v_result VARCHAR2(500);
BEGIN
 -- Retrieve the most recent purchase details for the customer
 SELECT SALES.SALES_NUM, SALES.SALES_DATE, SALES.SALES_AMT, STOCK.STOCK_MODEL
 INTO v_sales_num, v_sales_date, v_sales_amt, v_stock_model
 FROM SALES 
 JOIN STOCK ON SALES.STOCK_ID = STOCK.STOCK_ID
 WHERE SALES.CUST_ID = p_cust_id
 ORDER BY SALES.SALES_DATE DESC
 FETCH FIRST 1 ROWS ONLY;
 
 -- Construct the result string
 v_result := 'Sales Number: ' || v_sales_num ||
 ', Sales Date: ' || TO_CHAR(v_sales_date, 'DD-MON-YYYY') ||
 ', Sales Amount: R ' || v_sales_amt ||
 ', Stock Model: ' || v_stock_model;
 RETURN v_result;
EXCEPTION
 WHEN NO_DATA_FOUND THEN
 RETURN 'No purchases found for the given customer ID.';
 WHEN OTHERS THEN
 RETURN 'An error occurred: ' || SQLERRM;
END fn_IT_Gear;
/
--Execute the Function
-- Enable DBMS_OUTPUT to display the output in SQL*Plus or SQL Developer
SET SERVEROUTPUT ON;
-- Declare a block to execute the function
DECLARE
 v_result VARCHAR2(500);
BEGIN
 -- Call the function with a valid customer ID
 v_result := fn_IT_Gear('C115');
 DBMS_OUTPUT.PUT_LINE(v_result);
 -- Call the function with an invalid customer ID to test exception handling
 v_result := fn_IT_Gear('C999');
 DBMS_OUTPUT.PUT_LINE(v_result);
END;
/


